<?php
/**
 * 		Datei: 					admin/func.bill.php
 * 		Erstellungsdatum:		28.12.2010
 * 		Letzte bearbeitung:		-
 * 		Beschreibung:			Funktionen f�r das bill zusatzmodul
 * 		Autor:					Andreas Gyr
 */
error_reporting(E_ALL);
if (!defined('ADMIN')) die('Diese Seite kann nicht manuell aufgerufen werden!');

// Gibt den Rechnungsstatus in Worten zur�ck
function getBillStatus($billStatus) {
	$status = array();
	$status[1] = '<span style="color:orange;">Offen</span>';
	$status[2] = '<span style="color:green;">Bezahlt</span>';
	$status[3] = '<span style="color:red;">Mahnung 1</span>';
	$status[4] = '<span style="color:red;">Mahnung 2</span>';
	$status[5] = '<span style="color:red;">Mahnung 3</span>';
	return $status[(int)$billStatus];
}

// �berpr�ft den Status anhand des Zeitstempfels und gibt
// den aktuellen Status zur�ck
function checkBillStatus($billStatus, $date) {
	// Tag in sekunden
	$tag_s = 86400;
	
	// Fristen in bezug auf erstellungsdatum der Rechnung
	$frist1 = option('zahlungsfrist1')*$tag_s;
	$frist2 = (option('zahlungsfrist2')*$tag_s)+$frist1;
	$frist3 = (option('zahlungsfrist2')*$tag_s)+$frist1+$frist2;
	$frist4 = (option('zahlungsfrist2')*$tag_s)+$frist1+$frist2+$frist3;
	
	switch ($billStatus) {
		case 1: 
			if(($date + $frist1) < time()) {
				$s = 3;
			} else {
				$s = 1;
			}
		break;
		case 2:
			$s = 2;
		break;
		case 3:
			if(($date + $frist2) < time()) {
				$s = 4;
			} else {
				$s = 3;
			}
		break;
		case 4:
			if(($date + $frist3) < time()) {
				$s = 5;
			} else {
				$s = 4;
			}
		break;
	}
	return $s;
}

// Setzte den Status der rechnung neu
function setBillStatus($billId, $status) {
	global $mysql_func, $prefix;
	$update = array('status' => $status);
	$mysql_func->update($update, $prefix.'z_bill', sql($billId));
}

// �berpr�ft ob die Rechnung wiederkehrende rechnung
// durchfef�hrt werden muss
function checkAgain($timeStamp, $mode) {
	$tag = (int) date('d', $timeStamp);
	$monat = (int) date('m', $timeStamp);
	$jahr = (int) date('Y', $timeStamp);
	$minute = (int) date('i', $timeStamp);
	$stunde = (int) date('H', $timeStamp);
	$sekunde = (int) date('s', $timeStamp);
	
	// Impuls in Modaten
	if($mode == 'j') {
		$impuls = 12;
	} elseif ($mode == 'h') {
		$impuls = 6;
	} elseif ($mode == 'q') {
		$impuls = 3;
	} elseif ($mode == 'm') {
		$impuls = 1;
	}
	
	// Berechnen des Again Zeitstempels
	$out_t = $tag;
	if(($monat + $impuls) > 12) {
		// gr�sser als 12 monate
		$dieses_jahr = 12 - $monat;
		$n�chses_jahr = $impuls - $dieses_jahr;
		$out_m = $n�chses_jahr;
		$jahr++;
	} else {
		$out_m = $monat+$impuls; 
	}
	$out_j = $jahr;
	$stamp = mktime($stunde, $minute, $sekunde, $out_m, $out_t, $out_j);
	
	// Vergleichen des Zeitstempel 
	if (time() > $stamp) {
		// Ausf�hren
		return true;
	} else {
		return false;
	}
}
?>