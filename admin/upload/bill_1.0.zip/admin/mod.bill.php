<?php
/**
 * 		Datei: 					admin/mod.bill.php
 * 		Erstellungsdatum:		25.12.2010
 * 		Letzte bearbeitung:		16.10.2011
 * 		Beschreibung:			Rechnungsmodul
 * 		Autor:					Andreas Gyr
 */
error_reporting(E_ALL);
if (!defined('ADMIN')) die('Diese Seite kann nicht manuell aufgerufen werden!');

// Funktionsdatei laden
require_once('func/func.bill.php');

// Ajax laden
$ajax = new Ajax();
require_once('ajax/ajax.bill.php');

class bill
{
	private $mode = array();
	private $request = array();
	
	function __construct($request = false){
		$this->mode['add_form'] 		= setMode(array('action' => 'add'), array('send' => false));
		$this->mode['add_tpl_form'] 	= setMode(array('action' => 'add_tpl'), array('send' => false));
		$this->mode['add'] 				= setMode(array('action' => 'add'), array('send' => true));
		$this->mode['add_tpl'] 			= setMode(array('action' => 'add_tpl'), array('send' => true));
		$this->mode['edit_form'] 		= setMode(array('action' => 'edit'), array('send' => false));
		$this->mode['edit_tpl_form'] 	= setMode(array('action' => 'edit_tpl'), array('send' => false));
		$this->mode['edit'] 			= setMode(array('action' => 'edit'), array('send' => true));
		$this->mode['edit_tpl'] 		= setMode(array('action' => 'edit_tpl'), array('send' => true));
		$this->mode['show'] 			= setMode(array('action' => 'show'), array('send' => false));
		$this->mode['show_tpl'] 		= setMode(array('action' => 'show_tpl'), array('send' => false));
		$this->mode['print'] 			= setMode(array('action' => 'print'), array('send' => false));
		$this->mode['delete']			= setMode(array('action' => 'delete'), array('send' => false));
		$this->mode['delete_tpl']		= setMode(array('action' => 'delete_tpl'), array('send' => false));
		
		// Request Handling
		if($request) {
			$this->request = $request;
		} else {
			$this->request = array_merge($_POST, $_GET);
		}
	}
	
	/**
	 * Hauptmethode
	 */
	function main() {
		// Immer anzeigen
		$this->option_box();
		
		switch (true) {
			case $this->mode['add_form']['check']: 			$this->add_form(); break;
			case $this->mode['add_tpl_form']['check']: 		$this->add_tpl_form(); break;
			case $this->mode['add']['check']: 				$this->add; break;
			case $this->mode['add_tpl']['check']: 			$this->add_tpl(); break;
			case $this->mode['edit_form']['check']: 		$this->edit_form(); break;
			case $this->mode['edit_tpl_form']['check']: 	$this->edit_tpl_form(); break;
			case $this->mode['edit']['check']: 				$this->edit; break;
			case $this->mode['edit_tpl']['check']: 			$this->edit_tpl(); break;
			case $this->mode['show']['check']: 				$this->show(); break;
			case $this->mode['show_tpl']['check']: 			$this->show_tpl(); break;
			case $this->mode['print']['check']: 			$this->b_print(); break;
			case $this->mode['delete']['check']: 			$this->delete(); break;
			case $this->mode['delete_tpl']['check']: 		$this->delete_tpl(); break;
			default:										$this->overview(); break;
		}
	}
	
	/**
	 * Optionenbox links
	 */
	function option_box() {
		global $style;
		
		// neue Rechnung erstellen link
		$link = icon_link('�bersicht', 'input-add', INDEX);
		$link .= icon_link('Neue Rechnung', 'input-add', $this->mode['add_form']['link']);
		$link .= icon_link('Neues Template', 'images-add-alt', $this->mode['add_tpl_form']['link']);
		$style->box('Optionen', $link, 'left');
	}
	
	/**
	 * Neue Rechnung Formular
	 */
	function add_form() {
		global $style, $mysql, $prefix, $ajax;
		
		// Rechnung erstellen - Formular
		$form = new form();
		$form->new_group('Kundeninformationen');
		$mysql->select('id,vorname,nachname', $prefix.'customer');
		$options = array();
		while ($customer = $mysql->fetchRow()) {
			$options[$customer['id']] = $customer['vorname'].' '.$customer['nachname'];
		}
		$form->select('Kunde:', 'customer', $options);
		$form->checkbox('Andere rechnungsadresse?', 'other', array('Ja' => 'Ja'));
		$form->textarea('Rechnungsadresse:', 'bill_address', '', 5, 60, false);
		
		// Produkte
		$form->new_group('Produkt hinzuf�gen');
		$options = array();
		$mysql->select('id,name', $prefix.'product', 'ORDER BY id ASC'); // Produkte auslesen
		while ($product = $mysql->fetchRow()) {
			$options[$product['id']] = $product['name']; // produkte zuordnen
		}
		$form->select('Produkt:', 'product', $options); // Ajax Formularfeld
		$form->input('Menge:', 'menge', '', 'text', 15, 5, 0); // Ajax Formularfeld
		$form->button('Produkt hinzuf�gen', '', 'onclick="addProduct();"');
		
		// Produkte�bersicht Ausgabe der Liste (AJAX)
		$form->new_group('Produkte�bersicht');
		// Liste f�r die erste ansicht. (Keine Eintr�ge!)
		$list = new liste('Produkte�bersicht');
		$columns = array();
		$columns['Produkt'] = '';
		$columns['Menge'] = 60;
		$columns['Preis pro St�ck'] = '';
		$columns['Preis'] = '';
		$list->add_columns($columns);
		$form->add_code(
			// AJAX: Vorladefunktion ausgeben
			$ajax->getPreload().
			
			// AJAX: Resultat ausgeben
			$ajax->getResult($list->get())
		);
		
		// Ajax Ausf�hren
		$ajax->run();
		
		// AJAX: JS Code in HTML header einf�gen
		$style->add_js($ajax->getJS());
		
		$form->new_group('Rechnungsinformationen');
		$form->input('Referenznummer:', 'referenznummer', '', 'text', 40, 250, 0); // optional
		$form->textarea('Zahlungszweck:', 'zahlungszweck', '', 5, 40, 0); // optional
		$form->textarea('Notizen:', 'notizen', '', 5, 55, 0); // optional
		$form->submit();
		$style->box('Rechnung erstellen', $form->get());
	}
	
	/**
	 * Neues Rechnungstemplate Formular
	 */
	function add_tpl_form() {
		global $style;
		
		$form = new form();
		$form->new_group('Template ausw�hlen');
		$form->input('Name:', 'name');
		$options = array();
		$pfad = opendir(option('rel_path')."templates/");
		while ($datei = readdir($pfad)) {
			if ($datei != '.' && $datei != '..' && !is_dir(option('rel_path').'templates/'.$datei) && substr($datei,0,5) == 'bill.' && strrchr($datei, '.') == '.php') {
				$options[$datei] = $datei;
			}
		}
		closedir($pfad);
		$form->select('Template:', 'path', $options);
		$form->submit('Template hinzuf�gen');
		$style->box('Neues Template hinzuf�gen', $form->get());
	}
	
	/**
	 * Neue Rechnung Eintrag
	 */
	function add() {
		global $style, $mysql, $prefix;
		
		$products = array();
		$menges = unserialize(base64_decode($this->request['menges']));
		$keys = unserialize(base64_decode($this->request['keys']));
		$i = 0;
		foreach (unserialize(base64_decode($this->request['products'])) as $product_id) {
			$products[$keys[$i]][$product_id] = $menges[$keys[$i]];
			$i++;
		}
		$insert = array();
		$insert['customer'] = sql($this->request['customer']);
		$insert['kundennummer'] = $mysql->get_from_id('kundennummer', $prefix.'customer', $insert['customer']);
		$mysql->select('id', $prefix.'bill', 'WHERE customer = '.sql($insert['customer']));
		$insert['rechnungsnummer'] = $insert['kundennummer'].$mysql->count();
		$insert['product_data'] = sql(serialize($products));
		$insert['date'] = time();
		$insert['referenznummer'] = sql($this->request['referenznummer']);
		$insert['zahlungszweck'] = sql($this->request['zahlungszweck']);
		$insert['notizen'] = sql($this->request['notizen']);
		$insert['status'] = sql(1); // Rechnung offen
		$insert['rechnungsadresse'] = (@$this->request['other'] == 'on' ? sql($this->request['bill_address']) : sql(''));
		$insert['betrag'] = sql($this->request['preis_total']);
		$mysql->insert($insert, $prefix.'bill');
		$style->box(p_icon().'Erfolgreich!', 'Die Rechnung wurde erfolgreich erstellt.'.back_overview());
	}
	
	/**
	 * Neues Rechnungstemplate Eintrag
	 */
	function add_tpl() {
		global $style, $mysql, $prefix;
		
		$insert = array();
		$insert['name'] = sql($this->request['name']);
		$insert['path'] = sql($this->request['path']);
		$insert['date'] = sql(time());
		$mysql->insert($insert, $prefix.'bill_template');
		$style->box(p_icon().'Erfolgreich!', 'Das Template wurde erfolgreich erstellt.'.back_overview());
	}
	
	/**
	 * Rechnung bearbeiten Formular
	 */
	function edit_form() {
		global $style, $mysql, $prefix, $ajax;
		
		$mysql->id_select('*', $prefix.'bill', sql($this->request['id']));
		$bill = $mysql->fetchRow();
		
		$form = new form();
		$form->new_group('Kundeninformationen');
		$mysql->select('id,vorname,nachname', $prefix.'customer');
		$options = array();
		while ($customer = $mysql->fetchRow()) {
			$options[$customer['id']] = $customer['vorname'].' '.$customer['nachname'];
		}
		$form->select('Kunde:', 'customer', $options, 1, 0, $bill['customer']);
		$form->checkbox('Andere rechnungsadresse?', 'other', array('Ja' => 'Ja'), ($bill['rechnungsadresse'] == '' ? '' : 'Ja'));
		$form->textarea('Rechnungsadresse:', 'bill_adresse', $bill['rechnungsadresse'], 5, 60, false);
		
		$form->new_group('Rechnungsstatus');
		$form->checkbox('Bezahlt?', 'bezahlt', array('Ja' => 'Ja'), ($bill['status'] == 2 ? 'Ja' : ''));
		
		// Produkte
		$form->new_group('Produkt hinzuf�gen');
		$options = array();
		$mysql->select('id,name', $prefix.'product', 'ORDER BY id ASC'); // Produkte auslesen
		while ($product = $mysql->fetchRow()) {
			$options[$product['id']] = $product['name']; // produkte zuordnen
		}
		$form->select('Produkt:', 'product', $options); // Ajax Formularfeld
		$form->input('Menge:', 'menge', '', 'text', 15, 5, 0); // Ajax Formularfeld
		$form->button('Produkt hinzuf�gen', '', 'onclick="addProduct();"');
		
		// Produkte�bersicht Ausgabe der Liste (AJAX)
		$form->new_group('Produkte�bersicht');
		$JSCode = '';
		// Liste f�r die erste ansicht. (Keine Eintr�ge!)
		$list = new liste('Produkte�bersicht');
		$columns = array();
		$columns['Produkt'] = '';
		$columns['Menge'] = 60;
		$columns['Preis pro St�ck'] = '';
		$columns['Preis'] = '';
		$columns['Del'] = '';
		$list->add_columns($columns);
		$total_preis = 0;
		$products = unserialize($bill['product_data']);
		$menges = array();
		$keys = array();
		foreach ($products as $key => $arr) {
			foreach ($arr as $product_id => $menge) {
				// JS Arrays f�r Produkteliste eintrag
				$JSCode .= 	'products['.$key.'] = '.$product_id.';
						menges['.$key.'] = '.$menge.';
						keys['.$key.'] = '.$key.';
						xyz = '.$key.';
				';
				
				$menges[$key] = $menge; 
				$keys[$key] = $key;
				
				$data = array();
				$data[] = $mysql->get_from_id('name', $prefix.'product', sql($product_id));
				$data[] = (int) $menge;
				$data[] = ((int)$mysql->get_from_id('price', $prefix.'product', sql($product_id))).option('currency');
				$data[] = ($data[1] * $data[2]).option('currency'); // menge * preis pro st�ck
				$data[] = link_icon('Produkt l�schen', 'system-delete', 'onclick="delProduct('.$key.');"');
				// Total preis
				$total_preis +=	$data[3]; // Preis dazurechnen
				$list->add_row($data);
			}
		}
		
		// Hidden formularfelder f�r �bergabe
		$hidden = 	'<input type="hidden" name="products" value="'.base64_encode(serialize($products)).'" />
					<input type="hidden" name="menges" value="'.base64_encode(serialize($menges)).'" />
					<input type="hidden" name="keys" value="'.base64_encode(serialize($keys)).'" />
					<input type="hidden" name="preis_total" value="'.$total_preis.'" />';
		
		$JSCode .= 'xyz++;';
		$ajax->registJSCode($JSCode);
		$data = array();
		$data[] = '<strong>Preis Total:</strong>';
		$data[] = '';
		$data[] = '';
		$data[] = '<strong>'.((int) $total_preis).option('currency').'</strong>';
		$data[] = '';
		$list->add_row($data);
		$form->add_code(
			// AJAX: Vorladefunktion ausgeben
			$ajax->getPreload().
			
			// AJAX: Resultat ausgeben
			$ajax->getResult($list->get().$hidden)
		);
		
		// Ajax Ausf�hren
		$ajax->run();
		
		// AJAX: JS Code in HTML header einf�gen
		$style->add_js($ajax->getJS());
		
		$form->new_group('Rechnungsinformationen');
		$form->input('Referenznummer:', 'referenznummer', $bill['referenznummer'], 'text', 40, 250, 0); // optional
		$form->textarea('Zahlungszweck:', 'zahlungszweck', $bill['zahlungszweck'], 5, 40, 0); // optional
		$form->textarea('Notizen:', 'notizen', $bill['notizen'], 5, 55, 0); // optional
		$form->submit();
		$style->box('Rechnung bearbeiten', $form->get());
	}
	
	/**
	 * Rechnungstemplate bearbeiten Formular
	 */
	function edit_tpl_form() {
		global $style, $mysql, $prefix;
		
		$mysql->id_select('*', $prefix.'bill_template', sql($this->request['id']));
		$template = $mysql->fetchRow();
		
		$form = new form();
		$form->new_group('Template ausw�hlen');
		$form->input('Name:', 'name', $template['name']);
		$options = array();
		$pfad = opendir(option('rel_path')."templates/");
		while ($datei = readdir($pfad)) {
			if ($datei != '.' && $datei != '..' && !is_dir(option('rel_path').'templates/'.$datei) && substr($datei,0,5) == 'bill.' && strrchr($datei, '.') == '.php') {
				$options[$datei] = $datei;
				if($template['path'] == $datei) {
					$selected = $datei;
				}
			}
		}
		closedir($pfad);
		$form->select('Template', 'path', $options, 1, false, $selected);
		$form->submit('Template bearbeiten');
		$style->box('�nderungen speichern', $form->get());
	}
	
	/**
	 * Rechnung bearbeiten Eintrag
	 */
	function edit() {
		global $style, $mysql, $prefix;
		
		$products = array();
		$menges = unserialize(base64_decode($this->request['menges']));
		$keys = unserialize(base64_decode($this->request['keys']));
		$i = 0;
		foreach (unserialize(base64_decode($this->request['products'])) as $product) {
			foreach ($product as $id => $m) {
				$products[$keys[$i]][$id] = $menges[$keys[$i]];
				$i++;
			}
		}
		$update = array();
		$update['customer'] = sql($this->request['customer']);
		$update['kundennummer'] = $mysql->get_from_id('kundennummer', $prefix.'customer', $update['customer']);
		$mysql->select('id', $prefix.'bill', 'WHERE customer = '.sql($update['customer']));
		$update['rechnungsnummer'] = $update['kundennummer'].$mysql->count();
		$update['product_data'] = sql(serialize($products));
		$update['date'] = time();
		$update['referenznummer'] = sql($this->request['referenznummer']);
		$update['zahlungszweck'] = sql($this->request['zahlungszweck']);
		$update['notizen'] = sql($this->request['notizen']);
		if(@$this->request['bezahlt'] == 'on') {
			$update['status'] = sql(2); 
		}
		$update['rechnungsadresse'] = (@$this->request['other'] == 'on' ? sql($this->request['bill_address']) : sql(''));
		$update['betrag'] = sql($this->request['preis_total']);
		$mysql->update($update, $prefix.'bill', sql($this->request['id']));
		$style->box(p_icon().'Bearbeitung erfolgreich!', 'Die Rechnung konnte erfolgreich bearbeitet werden!'.back_overview());
	}
	
	/**
	 * Rechnungstemplate bearbeiten Eintrag
	 */
	function edit_tpl() {
		global $style, $mysql, $prefix;
		
		$update = array();
		$update['name'] = sql($this->request['name']);
		$update['path'] = sql($this->request['path']);
		$update['date'] = sql(time());
		$mysql->update($update, $prefix.'bill_template', sql($this->request['id']));
		$style->box(p_icon().'Erfolgreich!', 'Das Template wurde erfolgreich bearbeitet.'.back_overview());	
	}
	
	/**
	 * Rechnung anzeigen
	 */
	function show() {
		global $style, $mysql, $prefix;
		
		$mysql->id_select('*', $prefix.'bill', sql($this->request['id']));
		$bill = $mysql->fetchRow();
		
		$list = new liste('Rechnung: '.$bill['rechnungsnummer']);
		$list->add_columns(array('' => '50%', ' ' => ''));
		$list->add_row(array(liste_title('ID'), $bill['id']));
		$mysql->id_select('vorname,nachname', $prefix.'customer', sql($bill['customer']));
		$customer = $mysql->fetchRow();
		$list->add_row(array(liste_title('Kunde'), $customer['vorname'].$customer['nachname']));
		$list->add_row(array(liste_title('Kundennummer'), $bill['kundennummer']));
		$list->add_row(array(liste_title('Rechnungsadresse'), $bill['rechnungsadresse']));
		$list->add_row(array(liste_title('Betrag'), ($bill['betrag']).option('currency')));
		$list->add_row(array(liste_title('Status'), getBillStatus($bill['status'])));
		//$list->add_row(array(liste_title('Template'), $bill['template']));
		$list->add_row(array(liste_title('Referenznummer'), $bill['referenznummer']));
		$list->add_row(array(liste_title('Zahlungszweck'), $bill['zahlungszweck']));
		$list->add_row(array(liste_title('Notizen'), $bill['notizen']));
		// Produkteliste erstellen
		$product_data = unserialize($bill['product_data']);
		$products = '';
		foreach ($product_data as $key => $arr) {
			foreach ($arr as $product_id => $menge_anz) {
				$products .= $mysql->get_from_id('name', $prefix.'product', sql($product_id)).' ('.$menge_anz.')<br />';
			}
		}
		$list->add_row(array(liste_title('Produkte'), $products));
		$list->add_row(array(liste_title('Erstellungsdatum'), date('d.m.Y H:i', $bill['date'])));
		$style->add($list->get());
		
		// Bearbeiten Button
		$form = new form();
		$form->button('Datensatz bearbeiten', $this->mode['edit_form']['link'].'&id='.$this->request['id']);
		$style->add($form->get());
	}
	
	/**
	 * Rechnungstemplate anzeigen
	 */
	function show_tpl() {
		global $style, $mysql, $prefix;
		
		$mysql->id_select('*', $prefix.'bill_template', sql($this->request['id']));
		$template = $mysql->fetchRow();
		
		$list = new liste('Template: '.$template['name']);
		$list->add_columns(array(' ' => '50%', '' => ' '));
		$list->add_row(array(liste_title('ID'), $template['id']));
		$list->add_row(array(liste_title('Name'), $template['name']));
		$list->add_row(array(liste_title('Datei'), $template['path']));
		$list->add_row(array(liste_title('date'), date('d.m.Y', $template['date'])));
		$style->add($list->get());
		
		// Bearbeiten Button
		$form = new form();
		$form->button('Datensatz bearbeiten', $this->mode['edit_tpl_form']['link'].'&id='.$this->request['id']);
		$style->add($form->get());
	}
	
	/**
	 * Rechnung l�schen
	 */
	function delete() {
		global $style, $mysql, $prefix;
		
		$mysql->delete($prefix.'bill', sql($this->request['id']));
		$style->box(p_icon().'Erfolgreich!', 'Die Rechnung wurde erfolgreich gel�scht!'.back_overview());
	}
	
	/**
	 * Rechnungstemplate l�schen
	 */
	function delete_tpl() {
		global $mysql, $style, $prefix;
		
		$mysql->delete($prefix.'bill_template', sql($this->request['id']));
		$style->box(p_icon().'Erfolgreich!', 'Das Rechnungstemplate wurde erfolgreich gel�scht!'.back_overview());
	}
	
	/**
	 * Rechnung drucken
	 */
	function b_print() {
		global $mysql, $prefix, $style, $ajax;
		
		$mysql->select('id,name,path', $prefix.'bill_template');
		// Pr�fen ob min. ein Template existiert
		if($mysql->count() > 0) {
			$form = new form();
			$form->new_group('Template');
			$options = array();
			while ($template = $mysql->fetchRow()) {
				$options[$template['path']] = $template['name'];
			}
			$form->select('Template:', 'template', $options);
			$form->input('', 'id', $this->request['id'], 'hidden');
			$form->button('Zum Ausdruck..', '', 'onclick="printBill();"');
			
			// Ajax
			$ajax->run();
			$style->add_js($ajax->getJS());
			$style->box('Drucken', $form->get());
		} else {
			$style->box(n_icon().'Fehler!', 'Es existieren noch keine Templates zu ausdrucken.'.back_overview());
		}
	}
	
	/**
	 * �bersicht
	 */
	function overview() {
		global $style, $mysql, $prefix;
		
		$list = new liste('Alle Rechnungen');
		$columns = array();
		$columns['ID'] = 30;
		$columns['Kundennummer'] = '';
		$columns['Rechnungsnummer'] = '';
		$columns['Betrag'] = '';
		$columns['Status'] = '';
		$columns['Optionen'] = '';
		$list->add_columns($columns);
		
		$mysql->select('*', $prefix.'bill', 'ORDER BY id DESC');
		while ($bill = $mysql->fetchRow()) {
			// Status �berpr�fen
			$billstatus = checkBillStatus($bill['status'], $bill['date']);
			echo $billstatus;
			if($bill['status'] != $billstatus) {
				setBillStatus($bill['id'], $billstatus);
				$bill['status'] = $billstatus;
			}
			
			$data = array();
			$data[] = $bill['id'];
			$data[] = $bill['kundennummer'];
			$data[] = $bill['rechnungsnummer'];
			$data[] = ($bill['betrag'].option('currency'));
			$data[] = getBillStatus($bill['status']);
			$data[] = 	option_icon('edit', INDEX.'&id='.$bill['id']).
						option_icon('delete', INDEX.'&id='.$bill['id']).
						option_icon('show', INDEX.'&id='.$bill['id']).
						link_icon('drucken', 'printer', 'href="'.INDEX.'&action=print&id='.$bill['id'].'"');
			$list->add_row($data);
		}
		$style->add($list->get());
	}
}

$bill = new bill();
$bill->main();
?>