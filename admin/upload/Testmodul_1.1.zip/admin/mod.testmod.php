<?php
/**
 * 		Datei: 					admin/mod.testmod.php
 * 		Erstellungsdatum:		02.10.2011
 * 		Letzte bearbeitung:		-
 * 		Beschreibung:			Testmodul
 * 		Autor:					Andreas Gyr
 */
error_reporting(E_ALL);

$style->box('Test', 'dies inst ein tesssssssssst!');
?>